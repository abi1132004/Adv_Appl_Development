package com.example.boat.enumerated;
public enum Role {
    USER, ADMIN;
}
