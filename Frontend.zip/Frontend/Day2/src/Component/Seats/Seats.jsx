import React from 'react'

const Seats = () => {
  return (
    <div>Seats</div>
  )
}

export default Seats