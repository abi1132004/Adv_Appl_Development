import React from 'react'

const Users = () => {
  return (
    <div>Users</div>
  )
}

export default Users