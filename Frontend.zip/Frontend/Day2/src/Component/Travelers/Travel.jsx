import React from 'react'

const Travel = () => {
  return (
    <div>Travel</div>
  )
}

export default Travel