import { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import "./LoginPage.css";

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.get('http://localhost:8081/api/users/login', {
        params: {
          email,
          password,
        },
      });

      console.log(response.data); // handle success response
    } catch (error) {
      console.error('Login failed', error); // handle error
    }
  };

  return (
    <div id='div32'>
      <h2 className='h2log'>Login Page</h2>
      <br/>
      <form className='formlog' onSubmit={handleLogin}>
        <label className='labellog'>
          Email:<br/><br/>
          <input type="email" className='inputlog' value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <br/>
        <label>
          Password:<br/><br/>
          <input type="password" className='inputlog' value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <br />
        <button type="submit" className='buttlog'>
          <Link to="/Main">
          Login
          </Link>
          </button>
      </form>
      <p className='plog'>
        Dont have an account?
         <Link to="/RegisterPage">
          Register
          </Link>
      </p>
    </div>
  );
};

export default LoginPage;