// RegisterPage.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './RegisterPage.css';

const RegisterPage = () => {
  const [user, setUser] = useState({
    username: '',
    password: '',
    gender: '',
    age: 0,
    email: '',
    phone: '',
    state: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleRegistration = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8081/api/users/register', user);

      console.log(response.data); // handle success response

      // If registration is successful, navigate to the login page
      navigate('/LoginPage');
    } catch (error) {
      console.error('Registration failed', error); // handle error
    }
  };

  return (
    <div id='div3'>
      <h2>Register Page</h2>
      <form className="formlog1" onSubmit={handleRegistration}>
        <label>
          Username:<br/><br/>
          <input type="text" name="username" value={user.username} onChange={handleChange} />
        </label>
        <br />
        <label>
          Password:<br/><br/>
          <input type="password" name="password" value={user.password} onChange={handleChange} />
        </label>
        <br />
        <label>
          Gender:<br/><br/>
          <input type="text" name="gender" value={user.gender} onChange={handleChange} />
        </label>
        <br />
        <label>
          Age:<br/><br/>
          <input type="number" name="age" value={user.age} onChange={handleChange} />
        </label>
        <br />
        <label>
          Email:<br/><br/>
          <input type="email" name="email" value={user.email} onChange={handleChange} />
        </label>
        <br />
        <label>
          Phone:<br/><br/>
          <input type="text" name="phone" value={user.phone} onChange={handleChange} />
        </label>
        <br />
        <label>
          State:<br/><br/>
          <input type="text" name="state" value={user.state} onChange={handleChange} />
        </label>
        <br /><br/><br/>
        <button type="submit">Register</button>
      </form>
      <p>
        Already have an account? <Link to="/LoginPage">Login</Link>
      </p>
    </div>
  );
};

export default RegisterPage;
